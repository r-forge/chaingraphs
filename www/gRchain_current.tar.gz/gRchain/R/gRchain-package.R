#' gRchain: Chain Graph Models in R 
#' 
#' Fits (block) chain graph models. The package contains various functions, wrappers, methods and classes for fitting, plotting and displaying different chain graph models. Currently the Cox Wermuth (1996) strategy is implemented based on the description in Caputo et al. (1997) together with some liberal interpretations of details by the package authors. Traceable regressions will follow.   
#'
#' The stops package provides five categories of important functions:
#'
#' Models & Algorithms:
#' \itemize{
#' \item coxwer() ... which fits a block recursive chain graph model as in Cox and Wermuth (1996).
#' }
#'
#' 
#' Helper functions:
#' \itemize{
#' \item prep_coxwer()... A function to set up the variable frame 
#'}
#' 
#' Convenience functions:
#' \itemize{
#' \item adjmatrix() ... returns an adjacency matrix for the chain graph 
#' \item write_cw() ... write a plot of the graphical model to a file
#'}
#'
#' Methods: 
#' For most of the objects returned by the high-level functions S3 classes and methods for standard generics were implemented, including print, summary, plot, plot, predict.
#'
#' References:
#' \itemize{
#' \item Caputo, A., Heinicke, A. \& Pigeot, I. (1997). A graphical chain model derived from a model selection strategy for the sociologists graduates study. \emph{Collaborative Research Center 386, Discussion Paper 73.}
#' \item Cox, D. \& Wermuth, N. (1996). \emph{Multivariate Dependencies: Models, Analysis, Interpretation}. Florida:Chapman\&Hall/CRC.
#' \item Rusch, T., Hatzinger, R. and Wurzer, M. (2013) Chain Graph Models in R: Implementing the Cox-Wermuth Procedure. Psychoco 2013, Zuerich, Switzerland. 
#' \item Wurzer, M. \& Hatzinger, R. (2013). Using Graphical Models in Microsimulation. In C. O'Donoghue (ed.), \emph{New Pathways In Microsimulation}. Ashgate Publishing.
#' }
#' 
#' Authors: Thomas Rusch, Marcus Wurzer, Reinhold Hatzinger
#' Contributors: Kathrin Gruber
#' 
#' Maintainer: Thomas Rusch
#'
#'
#' @examples
#' 
#' data(cmc)
#' data(cmc_prep)
#' #this is a 5 block model with age being
#' #purely explanatory (block 5) and nRchild and
#' #contraceptive being purely the targets (block 1)
#' #Using a var.frame
#' cmc_prep
#' res_cmc <- coxwer(var.frame=cmc_prep, data=cmc)
#' print(res_cmc) #Prints adjacency matrix
#' summary(res_cmc,target="contraceptive") #model path to "contraceptive" as the target variable
#'
#' #Using a formula
#' #vartype is automatically detected which is crude for non-factors
#' res_cmc2<-coxwer(contraceptive + nrChild ~                          #block 1 - only targets
#'                  mediaExp ~                                         #block 2
#'                  solIndex ~                                         #block 3
#'                  wifeRel + wifeWork + husbOcc + wifeEdu + husbEdu ~ #block 4
#'                  age,                                               #block 5 - purely explanatory
#'                  data=cmc) 
#'\dontrun{ 
#' #Using a formula and specifying the vartype
#' #(so the algorithm can use better models for the metric/continuous variables)
#' res_cmc3<-coxwer(contraceptive + nrChild ~
#'                  mediaExp ~
#'                  solIndex ~
#'                  wifeRel + wifeWork + husbOcc + wifeEdu + husbEdu ~
#'                  age,
#'                  vartype=c("cate","count","bin","ord","bin","bin","ord","ord","ord","metric"),
#'                  data=cmc)
#'
#' plot(res_cmc3)
#' }
#' 
#' @docType package
#' @name gRchain
NULL
